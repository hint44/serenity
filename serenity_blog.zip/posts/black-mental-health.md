# Mental Health in the Black Community: Breaking the Silence

For too long, mental health in Black communities has been hidden behind silence, stigma, and shame. But the tide is turning — and you’re part of the change.

## Generational Silence
We’ve been taught to “pray it away” or “stay strong,” but emotional wounds need care, not denial.

## Culturally Competent Care
There are therapists who understand what it means to live at the intersection of culture, race, and history — and they’re here for you.

## Why Speaking Up Matters
When we talk about mental health, we save lives — starting with our own.

## You’re Not Alone
Platforms like [BetterHelp](https://www.betterhelp.com/?affiliate=serenity) let you connect with someone who listens, understands, and guides — in privacy and safety.

---

**Let’s normalize healing. Let’s talk about it.**
