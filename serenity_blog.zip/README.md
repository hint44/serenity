# Serenity 🌿 — A Mental Wellness Blog

Welcome to Serenity — a gentle space for mental clarity, self-growth, and emotional healing.  
Our mission is to create accessible, inclusive content for the Ethiopian diaspora and other underserved communities.

## 💼 Affiliate Disclosure

Some links on this website are affiliate links.  
This means we may earn a small commission if you click through and make a purchase — at **no extra cost to you**.

We only recommend services we believe in.  
Our first affiliate partner is **[BetterHelp](https://www.betterhelp.com/?affiliate=serenity)** — an online therapy platform making mental health support accessible globally.

## 📁 Project Structure

```
/index.html          ← Homepage
/posts               ← Blog posts (.md format)
/styles/style.css    ← Theme styles (soft green & beige)
/components          ← Newsletter form
README.md            ← You are here
```

## 👇 Want to Contribute?

More stories, translations, and mental wellness resources are coming.  
Stay calm, stay open, and stay growing. ✨
